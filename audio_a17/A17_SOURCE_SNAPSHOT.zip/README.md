# A17 corresponding source snapshot and frozen build inputs

This archive accompanies PATCH A17 SHA256 6f00e104b1b52a56aa69b2af3d57d0283a692fdd9ef9002e41d3c3fe8249fffe.

`source/` is the corresponding project source/configuration/dependency snapshot, including unchanged upstream notices. It excludes SDKs, build folders, generated program images, game ROMs, BIOS, saves and PATCH/PRE resources. Historical baseline documents inside source describe their earlier stage; the public A17 README is the current status.

The PCM changes are in ARM7 GbaSound7.c/.h and GbaSoundIpcService.cpp. The inherited A16 wave conversion is an object-level fixed-layout change: 120-16*n rather than the historical text's 127-17*n. Four ARM instructions in GbSound.o were changed without changing instruction count/relocations. `build_inputs/A16_GbSound_fixed.o` preserves the actual compiled wave handler. Do not claim an ordinary rebuild from the historical GbSound.c text reproduces A17.

`build_inputs/` contains the original A17 ARM7 ELF, frozen bootstrap ARM9 ELF, fixed wave object, and the packaging icon. It contains only runner build inputs, not Nintendo BIOS or ROM data. ELF debugging data can retain original build paths.

To verify exact published-binary packaging: `python3 repack_exact.py /path/to/ndstool`. This verifies all archived source/input hashes, repacks frozen ELF inputs and requires the full A17 NDS SHA256. It is a packaging reproduction, not a claim that a clean compiler rebuild was repeated during this upload.

Original build: devkitARM r65 GCC 14.2.0 with the inherited project libnds/libtwl toolchain. Source building uses the project makefiles under `source/code/`. A clean rebuild must preserve or explicitly reapply the four fixed-layout wave instructions; a compiler that changes their locations requires fresh validation. No SDK is redistributed here.

This is the already user-auditioned A17 artifact. No M1/M2/M3 experiments or NR52/envelope changes are included. Original copyrights/licenses remain unchanged.
