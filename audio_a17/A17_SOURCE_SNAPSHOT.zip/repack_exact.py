from pathlib import Path
import hashlib,json,subprocess,shutil,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'SOURCE_SHA256.json').read_text())
for rel,want in manifest.items():
    assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==want,rel
tool=sys.argv[1] if len(sys.argv)>1 else shutil.which('ndstool')
assert tool, 'Pass a path to devkitPro ndstool as the first argument.'
target=root/'A17_REPACK.nds'
subprocess.run([tool,'-c',str(target),'-7',str(root/'build_inputs/A17_arm7.elf'),'-9',str(root/'build_inputs/A17_bootstrap_arm9.elf'),'-b',str(root/'build_inputs/icon.bmp'),'GBARunner 3;By Gericom;http://devkitpro.org'],check=True,capture_output=True)
assert hashlib.sha256(target.read_bytes()).hexdigest()=='6f00e104b1b52a56aa69b2af3d57d0283a692fdd9ef9002e41d3c3fe8249fffe'
print('Exact A17 file SHA256 verified:',target.name)
